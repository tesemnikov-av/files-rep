import pandas as pd
from datetime import datetime, timedelta
import statsmodels.api as sm
from influxdb import DataFrameClient
import os

import time

import configparser
import base64

from pyzabbix import ZabbixAPI
from .journeyman import rename

config = configparser.ConfigParser()
config.read('/joyce/app/joyce.conf')

TODAY = time.strftime("%Y-%m-%d %H:%M")

PATH = config['JOYCE']['PATH']

ZABBIX_HOST = config['ZABBIX']['SERVER']
ZABBIX_USER = config['ZABBIX']['USER']

ZABBIX_HASH_PASSWORD = os.environ.get('JOYCE_PASSWORD')
ZABBIX_PASSWORD = base64.b64decode(ZABBIX_HASH_PASSWORD).decode("utf-8")

INVERT_METRIC = (config['JOYCE']['INVERT_METRIC']).split(',')

INFLUX_HOST = config['INFLUXDB']['SERVER']
INFLUX_PORT = int(config['INFLUXDB']['PORT'])
INFLUX_DATABASE = config['INFLUXDB']['DATABASE']

z = ZabbixAPI(server=ZABBIX_HOST)
z.login(ZABBIX_USER, ZABBIX_PASSWORD)

INFLUX_CLIENT = DataFrameClient(INFLUX_HOST, INFLUX_PORT, INFLUX_DATABASE)


def write(df: pd.DataFrame, hostname: str, item_id: int, metric: str, source: str):
    """
    Save Time Series in DataBase and on the disk
    """
    assert source in ['original', 'prediction']
    INFLUX_CLIENT.write_points(df, database=INFLUX_DATABASE, measurement=metric, tags={'hostname' : hostname, 'source': source })
    df.to_csv(PATH + "/logs/"+str(hostname)+"_"+str(item_id)+"_"+str(metric)+"_" + source + ".csv")


class Prospector:
    """
         Loading historical data from Zabbix
    """

    def __init__(self, history_second_left: int, rolling_mean: int):
        """Constructor"""
        self.history_second_left = history_second_left
        self.rolling_mean = rolling_mean
    
    def load(self, hostname: str, item_id: int, metric: str) -> pd.DataFrame:
        df = pd.DataFrame(z.history.get(itemids=item_id, time_from=int(time.time() - self.history_second_left), history=0))
        df.clock = df.clock.apply(lambda d: datetime.fromtimestamp(int(d)).strftime('%Y%m%d %H:%M:%S'))
        df['clock'] = pd.to_datetime(df['clock'])
        df_day_original = df.set_index('clock')[['value']]

        metric = rename(metric)
 
        if metric in INVERT_METRIC:
            df_day_original['value'] = df_day_original['value'].apply(lambda x: 100 - round(float(x), 4))
 
        df_day_original['value'] = pd.to_numeric(df_day_original['value'])
        df_day_original = df_day_original.resample(str(self.rolling_mean) + 'min').mean()
        df_day_original['value'] = df_day_original['value'].apply(lambda x: str(round(x, 1)))

        write(df=df_day_original, hostname=hostname, metric=metric, item_id=item_id, source='original')


class Quacksalver:
    """
        Forecasting data with ML algoritm
    """

    def __init__(self, seasons: int, no_of_hours: int, freq: int):
        """Constructor"""
        self.seasons = seasons
        self.no_of_hours = no_of_hours
        self.freq = freq

    def forecast(self, hostname: str, dataframe: pd.DataFrame, item_id: int, metric: str)-> pd.DataFrame:
        """
            Forecast data
        """
        last_timestamp = dataframe['clock'][dataframe.shape[0] - 1]
        last_timestamp = datetime.strptime(last_timestamp, '%Y-%m-%d %H:%M:%S')
        first_prediction_timestamp = last_timestamp + timedelta(minutes=self.freq)
        last_prediction_timestamp = first_prediction_timestamp + timedelta(hours=(self.no_of_hours - 1))
        
        date = pd.date_range(first_prediction_timestamp, last_prediction_timestamp, freq=str(self.freq) + "min")
 
        """
            If the difference between the maximum and minimum values is less than ten percent, 
        then we will predict the average value. Otherwise, the prediction algorithm goes crazy.
            This is quite enough for us to detect anomalies.
        """
        if dataframe['value'].max() - dataframe['value'].min() < 5:
            forecast = pd.Series([dataframe['value'].mean() for _ in range(len(date))])
        else:
            mod = sm.tsa.SARIMAX(dataframe['value'], trend='n', order=(1, 1, 1), seasonal_order=(0, 1, 1, self.seasons),
                         enforce_stationarity=False , enforce_invertibility=False)
            results = mod.fit()

            forecast = results.predict(start=dataframe.shape[0], end=dataframe.shape[0] + (len(date) - 1), dynamic=True)
 
        dataframe = pd.DataFrame(forecast)
        dataframe['clock'] = date 
        dataframe['forecast'] = pd.to_numeric(dataframe[0])
        dataframe = dataframe[['clock', 'forecast']]
        dataframe = dataframe.set_index('clock')

        """
        Replace negative numbers by zero (if exist)
        """
        dataframe = dataframe.clip(lower=0)

        write(df=dataframe, hostname=hostname, item_id=item_id, source='prediction', metric=metric)
