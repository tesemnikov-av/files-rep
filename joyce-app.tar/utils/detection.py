from pyzabbix import ZabbixAPI
import pandas as pd
import time
import datetime
import glob
from statistics import mean
import configparser
import base64
import os

config = configparser.ConfigParser()
config.read('/joyce/app/joyce.conf')

PATH = config['JOYCE']['PATH']

ZABBIX_HOST = config['ZABBIX']['SERVER']
ZABBIX_USER = config['ZABBIX']['USER']
ZABBIX_HASH_PASSWORD = os.environ.get('JOYCE_PASSWORD')
ZABBIX_PASSWORD = base64.b64decode(ZABBIX_HASH_PASSWORD).decode("utf-8")

INVERT_METRIC = (config['JOYCE']['INVERT_METRIC']).split(',')
ROLLING_MEAN = int(config['JOYCE']['ROLLING_MEAN'])


z = ZabbixAPI(server=ZABBIX_HOST)
z.login(ZABBIX_USER, ZABBIX_PASSWORD)


# now = time.strftime("%Y-%m-%d %H")+":00:00"
hour = str(int(time.strftime("%H"))-1)

if len(hour) == 1 and hour != "-1":
    hour = "0"+str(hour)
elif hour == "-1":
    hour = 23

# now = time.strftime("%Y-%m-%d")+" "+str(hour)+":" + time.strftime("%M")+  ":00:00"


now = datetime.datetime.now()
now = str(now.replace(minute=(now.minute - (now.minute % ROLLING_MEAN )), second=0,microsecond=0))

# list hosts  for detection
df_clusters = pd.read_csv(PATH + '/hostname.clusters', names = ['tmp'])
df_clusters = df_clusters.tmp.str.split(expand=True)[[3]]
df_clusters.columns = ['host']
clusters = list(df_clusters.host.unique())
df_standalones = pd.read_csv(PATH + '/hostname.standalone', names = ['tmp'])
df_standalones = df_standalones.tmp.str.split(expand=True)[[0]]
df_standalones.columns = ['hostname']
standalones = list(df_standalones.hostname.unique())
df_excludes = pd.read_csv(PATH + '/hostname.exclude', names = ['tmp'])
df_excludes = df_excludes.tmp.str.split(expand=True)[[0]]
df_excludes.columns = ['hostname']
excludes = list(df_excludes.hostname.unique())
hostnames_for_detection  = [host for host in (clusters + standalones) if host not in excludes]


for host in hostnames_for_detection:
    for file in (glob.glob(PATH + 'logs/' + str(host)+"_" + "*pred.csv")):
    #    print(file)


#for file in (glob.glob("/joyce/app/logs/*pred.csv")):
        try:
            #print(file)
            df = (pd.read_csv(file))

            hostname = (str(file.split("_")[0]).split("/")[4])
            metric = (str(file.split("_")[2]))

            item_id = (str(file.split("_")[1]))
            #pred_values = int(df.query("clock == @now")['forecast'])
            pred_values = float(df.query("clock == @now")['forecast'])

            # WITH HISTORY DATA
            last_values = pd.DataFrame(z.history.get(itemids=item_id, time_from=int(time.time() - (ROLLING_MEAN * 60 + 1)), history=0))['value'].values.tolist()
            last_values = [float(i) for i in last_values]
            last_values = round((mean(last_values)), 4)

            # WITH TREND DATA
            #last_values = round(float(pd.DataFrame(z.trend.get(itemids=item_id, time_from=int(time.time() - 12200),  history=10)).tail(1)['value_avg']),2)

            if metric in INVERT_METRIC:
                last_values = round((100 - last_values), 4)

            ratio = abs(round(pred_values -  last_values, 2))
            if ratio > 19 and ratio < 30:
                flag= "WARNING"
            elif ratio > 29:
                flag = "CRITICAL"
            else:
                flag = "NORMAL"
            row = (hostname, metric, item_id, now, ratio, last_values, round(pred_values,2), flag)
            with open(PATH + '/messages.log','a') as f:
                f.write(str(row))
                f.write("\n")

        except BaseException as e:
            with open(PATH + '/debug.log','a') as f:
                f.write(str(now)+" Fail to check detection for "+str(hostname)+"\n "+str(e)+"\n")
