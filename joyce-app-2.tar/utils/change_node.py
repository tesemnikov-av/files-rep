from pyzabbix import ZabbixAPI
from influxdb import DataFrameClient
import statsmodels.api as sm
from datetime import datetime
import re

import pandas as pd
import time
import os

import configparser
import base64

config = configparser.ConfigParser()
config.read('/joyce/app/joyce.conf')

ZABBIX_HOST = config['ZABBIX']['SERVER']
ZABBIX_USER = config['ZABBIX']['USER']
ZABBIX_HASH_PASSWORD = os.environ.get('JOYCE_PASSWORD')
ZABBIX_PASSWORD = base64.b64decode(ZABBIX_HASH_PASSWORD).decode("utf-8")

z = ZabbixAPI(server=ZABBIX_HOST)
z.login(ZABBIX_USER, ZABBIX_PASSWORD)

# z = ZabbixAPI(url="http://observer.ca.sbrf.ru" , user="tesemnikov-av", password ="")

hosts = pd.DataFrame(z.host.get(groupids=137 , output=['hostid','name']))

historysecongleft = 60 * 60 + 3
lpar = ''

hosts_id = hosts[hosts.name.str.contains(lpar)]

switchover = []

for host_id in hosts_id['hostid']:
    hostname = list(hosts_id.query("hostid == @host_id")['name'])[0]
    metrics = []
    item_id = z.item.get(hostids=host_id, output=['itemid' , 'name'])
    for item in (item_id):
        
        if item['name'] == '[VCS_log] Info Log':# 'Available memory':
            metrics.append(([item['itemid'], item['name'], hostname]))
    
    for item_id, metric, hostname in metrics:
        df = pd.DataFrame(z.history.get(itemids=item_id, time_from=int(time.time() - historysecongleft), history=2, output=['value', 'clock']))
        if (len(df)) != 0:
            switchover.extend(df['value'])

if len(switchover) != 0:
    df = pd.DataFrame(switchover)[0].str.split(expand=True)[[0,1, 5,6,8,11]]
    df.columns = ['day', 'time', 'what' , 'SG_name', 'state', 'hostname']
    df = df.query("what == 'Group' and state == 'online' and SG_name != 'NIC_SG' and SG_name != 'NICSG' ").drop_duplicates()
    df['date'] =  pd.to_datetime(df[df.columns[0:2]].apply(lambda x: ' '.join(x.dropna().astype(str)), axis=1))
    df.drop(['day', 'time','what'], axis=1, inplace=True)
    df = df.sort_values(by='date')
    df = df.drop_duplicates(subset=['SG_name'], keep='last')[['SG_name', 'hostname']]
    
    for line in df.iterrows():
        hostname_file = open('/joyce/app/hostname.clusters', "rt")
        data = hostname_file.read()
        
        SG = line[1]['SG_name']
        hostname  = line[1]['hostname']
        data_new = re.sub(": "+str(SG)+".*", ": "+str(SG)+" "+str(hostname), data)
    
        if data == data_new:
            msg = " changed in /joyce/app/hostname.clusters file FAIL "
        else:
            msg = " changed in /joyce/app/hostname.clusters file OK "
            
        now = str(datetime.now())[0:19]
        
        with open('/joyce/app/clusters.log','a') as f:
            f.write(now + " "+str(hostname)+" "+ str(SG)+msg+"\n")
    
        hostname_file.close()
        hostname_file = open ('/joyce/app/hostname.clusters', "wt")
        hostname_file.write(data_new)
        hostname_file.close()
