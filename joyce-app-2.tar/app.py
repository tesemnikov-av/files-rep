import pandas as pd
import numpy as np
import glob
import time
import os

import configparser
import base64

from pyzabbix import ZabbixAPI
from influxdb import DataFrameClient
import statsmodels.api as sm
from datetime import datetime

from libs.timeseries import write, Prospector, Quacksalver
from libs.journeyman import rename, split_file_names

config = configparser.ConfigParser()
config.read('/joyce/app/joyce.conf')

TODAY = time.strftime("%Y-%m-%d %H:%M")

INVERT_METRIC = (config['JOYCE']['INVERT_METRIC']).split(',')
PATH = config['JOYCE']['PATH']

SEASONS = int(config['JOYCE']['SEASONS'])
METRICS = (config['JOYCE']['METRICS']).split(',')
NO_OF_HOURS = int(config['JOYCE']['NO_OF_HOURS'])
HISTORY_SECOND_LEFT = int(config['ZABBIX']['HISTORY_SECOND_LEFT'])
ROLLING_MEAN = int(config['JOYCE']['ROLLING_MEAN'])
SUBGROUP = config['JOYCE']['SUBGROUP']

ZABBIX_HOST = config['ZABBIX']['SERVER']
ZABBIX_USER = config['ZABBIX']['USER']
ZABBIX_HASH_PASSWORD = os.environ.get('JOYCE_PASSWORD')
ZABBIX_PASSWORD = base64.b64decode(ZABBIX_HASH_PASSWORD).decode("utf-8")
ZABBIX_GROUP_IDS = (config['ZABBIX']['GROUP_IDS']).split(',')

INFLUX_HOST = config['INFLUXDB']['SERVER']
INFLUX_PORT = int(config['INFLUXDB']['PORT'])
INFLUX_DATABASE = config['INFLUXDB']['DATABASE']

z = ZabbixAPI(server=ZABBIX_HOST)
z.login(ZABBIX_USER, ZABBIX_PASSWORD)

INFLUX_CLIENT = DataFrameClient(INFLUX_HOST, INFLUX_PORT, INFLUX_DATABASE)

prospector = Prospector(history_second_left=HISTORY_SECOND_LEFT, rolling_mean=ROLLING_MEAN)
quacksalver = Quacksalver(seasons=SEASONS, no_of_hours=NO_OF_HOURS, freq=ROLLING_MEAN)

hosts_id = pd.DataFrame(z.host.get(groupids=ZABBIX_GROUP_IDS, output=['hostid', 'name', 'status']))

if SUBGROUP != 'False':
    hosts_id = hosts_id[hosts_id.name.str.contains(SUBGROUP)][['hostid', 'name', 'status']]

for _, host in hosts_id.iterrows():
#    try:
        host_id, host_name, host_status = host
        
        if host_status == '0':

            metrics = []
            item_id = z.item.get(hostids=host_id, output=['itemid', 'name'])

            for item in (item_id):
                if item['name'] in METRICS:
                    metrics.append(([item['itemid'], item['name'], host_name]))

            for item_id, metric, hostname in metrics:
                prospector.load(host_name, item_id, metric)

#    except BaseException as e:
#        with open(PATH + '/debug.log', 'a') as f:
#            f.write(str(TODAY) + " Fail to get data for " + str(hostname) + "\n" + str(e) + "\n")

df_clusters = pd.read_csv(PATH + '/hostname.clusters', sep=" ")
df_clusters.columns = ['lpar1', 'lpar2', ':', 'SG', 'active']
df_clusters = df_clusters[['lpar1', 'lpar2']].drop_duplicates()

for row, col in df_clusters.iterrows():
   try:
        lpar1 = col['lpar1']
        lpar2 = col['lpar2']

        if lpar1 in hosts_id['name'].tolist() and lpar2 in hosts_id['name'].tolist():

            for metric in ['memory', 'user', 'system', 'swap']:
                file1_name = PATH + "/logs/" + str(lpar1) + "*" + str(metric) + "_orig.csv"
                file2_name = PATH + "/logs/" + str(lpar2) + "*" + str(metric) + "_orig.csv"
                file1 = glob.glob(file1_name)[0]
                file2 = glob.glob(file2_name)[0]
                df1 = pd.read_csv(file1)
                df2 = pd.read_csv(file2)
                df = pd.concat([df1[['clock', 'value']], df2[['clock', 'value']]], axis=1)
                df.columns = ['clock_1', 'lpar1', 'clock_2', 'lpar2']

                df['clus'] = df.apply(lambda x: x['lpar1'] if x['lpar1'] > x['lpar2'] else x['lpar2'], axis=1)

                df = df[['clock_1', 'clus']]
                df.columns = ['clock', 'value']
                df.to_csv(file1)
                df.to_csv(file2)

                df['clock'] = pd.to_datetime(df['clock'])
                df = df.set_index('clock')[['value']]
                df['value'] = df['value'].apply(lambda x: str(round(x, 4)))

                for host in [lpar1, lpar2]:
                    INFLUX_CLIENT.write_points(df, database='joyce_db', measurement=metric,
                                               tags={'hostname': host, 'source': 'cluster'})
    
   except BaseException as e:
       with open(PATH + '/debug.log', 'a') as f:
           f.write(str(TODAY) + " Fail to merge data for " + str(lpar1) + " " + str(lpar2) + " \n" + str(e) + "\n")

original_files = glob.glob(PATH + "logs/*" +  "*original.csv")


for file in original_files:
    """
    Find original files and make predictions
    """
    hostname, item_id, metric, _ = split_file_names(file)
    df = pd.read_csv(file)

    try:
        quacksalver.forecast(hostname, df, item_id, metric)
    except BaseException as e:
        with open(PATH + '/debug.log','a') as f:
            f.write(str(TODAY)+" Fail get prediction for "+str(hostname)+"\n"+str(e)+"\n")
