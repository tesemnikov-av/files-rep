import io
import pandas as pd
import streamlit as st
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

from cluster_tickets import (
    preprocess_texts,
    get_top_words_per_cluster,
    find_optimal_clusters,
    build_matrix,
)


def silhouette_table(X, max_clusters: int):
    rows, best_k = find_optimal_clusters(X, max_clusters=max_clusters)
    df = pd.DataFrame(rows, columns=["k", "silhouette"])
    return df, best_k


def build_report(texts, df_result, top_words, k, silhouette_avg):
    lines = []
    lines.append("ОТЧЕТ О КЛАСТЕРИЗАЦИИ ОБРАЩЕНИЙ")
    lines.append("=" * 80)
    lines.append("")
    lines.append(f"Всего обращений: {len(texts)}")
    lines.append(f"Количество кластеров: {k}")
    lines.append(f"Silhouette Score: {silhouette_avg:.3f}")
    lines.append("")
    for cluster_id in range(k):
        cluster_texts = df_result[df_result["Кластер"] == cluster_id]["Обращение"].tolist()
        lines.append("")
        lines.append(f"Кластер {cluster_id}: ({len(cluster_texts)} обращений)")
        lines.append(f"Топ-слова: {', '.join(top_words[cluster_id])}")
        lines.append("Обращения:")
        for t in cluster_texts:
            lines.append(f"  - {t}")
    lines.append("")
    return "\n".join(lines)


@st.cache_data(show_spinner=False)
def run_pipeline(df: pd.DataFrame, text_col: str, mode: str, max_features: int, min_df: int, max_df: float, ngram_max: int, max_clusters: int, n_top_words: int):
    texts = df[text_col].astype(str).fillna("").tolist()
    processed = preprocess_texts(texts)
    X, vectorizer, _ = build_matrix(
        processed_texts=processed,
        mode=mode,
        max_features=max_features,
        min_df=min_df,
        max_df=max_df,
        ngram_max=ngram_max,
    )
    sil_df, k = silhouette_table(X, max_clusters=max_clusters)
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = kmeans.fit_predict(X)
    sil_avg = float(silhouette_score(X, labels))
    top_words = get_top_words_per_cluster(vectorizer, kmeans, n_words=n_top_words) if vectorizer is not None else {i: [] for i in range(k)}
    out = df.copy()
    out["Кластер"] = labels
    out["Обработанный текст"] = processed
    return texts, processed, X.shape, sil_df, k, sil_avg, vectorizer, kmeans, top_words, out


def to_excel_bytes(df: pd.DataFrame):
    bio = io.BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        df.to_excel(writer, index=False)
    return bio.getvalue()


st.set_page_config(page_title="Кластеризация обращений", layout="wide")
st.title("Кластеризация обращений в поддержку")

with st.sidebar:
    st.subheader("Данные")
    uploaded = st.file_uploader("Excel (.xlsx)", type=["xlsx"])
    default_path = "support_tickets.xlsx"
    use_default = st.checkbox("Использовать support_tickets.xlsx из папки проекта", value=uploaded is None)

    st.subheader("Режим признаков")
    mode = st.selectbox("Признаки", ["tfidf", "emb", "both"], format_func=lambda x: {"tfidf": "TF-IDF", "emb": "Эмбеддинги rubert-tiny", "both": "TF-IDF + эмбеддинги"}[x])

    st.subheader("TF-IDF")
    max_features = st.slider("max_features", 200, 5000, 1000, 100)
    min_df = st.slider("min_df", 1, 10, 1, 1)
    max_df = st.slider("max_df", 0.3, 1.0, 0.8, 0.05)
    ngram_max = st.selectbox("ngram_range (1..N)", [1, 2, 3], index=1)

    st.subheader("Кластеры")
    max_clusters = st.slider("max_clusters", 2, 30, 10, 1)
    n_top_words = st.slider("топ-слов на кластер", 5, 30, 10, 1)

    run = st.button("Запустить", type="primary")

if uploaded is not None:
    df = pd.read_excel(uploaded)
elif use_default:
    df = pd.read_excel(default_path)
else:
    st.info("Загрузите файл или включите использование support_tickets.xlsx.")
    st.stop()

if df.empty:
    st.warning("Файл пустой.")
    st.stop()

text_candidates = [c for c in df.columns if df[c].dtype == object] or list(df.columns)
text_col = st.selectbox("Колонка с текстом обращения", text_candidates, index=text_candidates.index("Обращение") if "Обращение" in text_candidates else 0)

if not run:
    st.stop()

with st.spinner("Кластеризация..."):
    texts, processed, x_shape, sil_df, k, sil_avg, vectorizer, kmeans, top_words, out = run_pipeline(
        df=df,
        text_col=text_col,
        mode=mode,
        max_features=max_features,
        min_df=min_df,
        max_df=max_df,
        ngram_max=ngram_max,
        max_clusters=max_clusters,
        n_top_words=n_top_words,
    )

st.success(f"Готово: k={k}, silhouette={sil_avg:.3f}, TF-IDF={x_shape}")

left, right = st.columns([1, 1])

with left:
    st.subheader("Silhouette по k")
    st.dataframe(sil_df, use_container_width=True, hide_index=True)
    st.line_chart(sil_df.set_index("k")["silhouette"])

with right:
    st.subheader("Размеры кластеров")
    counts = out["Кластер"].value_counts().sort_index()
    st.bar_chart(counts)
    st.dataframe(counts.rename("count").reset_index().rename(columns={"index": "cluster"}), use_container_width=True, hide_index=True)

st.subheader("Топ-слова по кластерам")
top_words_df = pd.DataFrame(
    [{"cluster": cid, "top_words": ", ".join(words)} for cid, words in top_words.items()]
).sort_values("cluster")
st.dataframe(top_words_df, use_container_width=True, hide_index=True)

st.subheader("Примеры обращений")
cols = st.columns(2)
for cid in range(k):
    col = cols[cid % 2]
    with col:
        with st.expander(f"Кластер {cid} ({int(counts.get(cid, 0))})", expanded=False):
            st.write(", ".join(top_words[cid][:5]))
            examples = out[out["Кластер"] == cid][text_col].astype(str).head(10).tolist()
            st.write(pd.DataFrame({"Обращение": examples}))

st.subheader("Экспорт")
clustered_xlsx = to_excel_bytes(out[[text_col, "Кластер"]].rename(columns={text_col: "Обращение"}))
report_txt = build_report(texts, out.rename(columns={text_col: "Обращение"}), top_words, k, sil_avg).encode("utf-8")

st.download_button("Скачать support_tickets_clustered.xlsx", clustered_xlsx, file_name="support_tickets_clustered.xlsx")
st.download_button("Скачать clustering_report.txt", report_txt, file_name="clustering_report.txt")
st.dataframe(out, use_container_width=True, hide_index=True)

