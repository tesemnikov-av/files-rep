import re
import numpy as np
import pymorphy3
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from transformers import AutoTokenizer, AutoModel

morph = pymorphy3.MorphAnalyzer()
_tokenizer = None
_model = None


def clean_text(text):
    text = text.lower()
    text = re.sub(r'\S+@\S+', '', text)
    text = re.sub(r'http\S+|www\.\S+', '', text)
    text = re.sub(r'[^а-яёa-z0-9\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def lemmatize_text(text):
    stop_words = {'как', 'что', 'где', 'когда', 'кто', 'это', 'тот', 'этот', 'для', 'по'}
    words = [morph.parse(word)[0].normal_form for word in text.split() if len(word) >= 2]
    return ' '.join([w for w in words if w not in stop_words])


def preprocess_texts(texts):
    return [lemmatize_text(clean_text(text)) for text in texts]


def find_optimal_clusters(X, max_clusters=10):
    rows = []
    n_samples = X.shape[0]
    max_k = min(max_clusters, max(2, n_samples - 1))
    for k in range(2, max_k + 1):
        labels = KMeans(n_clusters=k, random_state=42, n_init=10).fit_predict(X)
        score = silhouette_score(X, labels)
        rows.append((k, float(score)))
    best_k = max(rows, key=lambda x: x[1])[0]
    return rows, best_k


def get_top_words_per_cluster(vectorizer, kmeans, n_words=10):
    feature_names = vectorizer.get_feature_names_out()
    top_words_per_cluster = {}
    for cluster_id in range(kmeans.n_clusters):
        centroid = kmeans.cluster_centers_[cluster_id]
        top_indices = centroid.argsort()[-n_words:][::-1]
        top_words_per_cluster[cluster_id] = [feature_names[i] for i in top_indices]
    return top_words_per_cluster


def get_rubert():
    global _tokenizer, _model
    if _tokenizer is None or _model is None:
        _tokenizer = AutoTokenizer.from_pretrained("cointegrated/rubert-tiny")
        _model = AutoModel.from_pretrained("cointegrated/rubert-tiny")
    return _tokenizer, _model


def get_embeddings(texts):
    import torch

    tokenizer, model = get_rubert()
    encoded = tokenizer(
        texts,
        padding=True,
        truncation=True,
        max_length=128,
        return_tensors="pt",
    )
    with torch.no_grad():
        out = model(**encoded)
    emb = out.last_hidden_state.mean(dim=1).cpu().numpy()
    return emb


def build_matrix(processed_texts, mode, max_features, min_df, max_df, ngram_max):
    if mode == "tfidf":
        vec = TfidfVectorizer(
            max_features=max_features,
            min_df=min_df,
            max_df=max_df,
            ngram_range=(1, ngram_max),
        )
        X = vec.fit_transform(processed_texts)
        return X, vec, None
    if mode == "emb":
        X = get_embeddings(processed_texts)
        return X, None, X
    if mode == "both":
        from sklearn.preprocessing import normalize
        from scipy.sparse import hstack

        vec = TfidfVectorizer(
            max_features=max_features,
            min_df=min_df,
            max_df=max_df,
            ngram_range=(1, ngram_max),
        )
        X_tfidf = vec.fit_transform(processed_texts)
        X_emb = get_embeddings(processed_texts)
        X_emb_norm = normalize(X_emb)
        X = hstack([X_tfidf, X_emb_norm])
        return X, vec, X_emb
    raise ValueError("unknown mode")

